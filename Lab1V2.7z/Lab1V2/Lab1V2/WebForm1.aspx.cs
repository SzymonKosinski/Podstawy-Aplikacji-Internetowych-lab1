﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab1V2
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void SubmitBtn_Click(object sender, EventArgs e)
        {
            Random r = new Random();
            int losuj = r.Next(1, 5);
            switch (losuj)
            {
                case 1:
                    imagebutton1.Visible = true;
                    imagebutton2.Visible = false;
                    imagebutton3.Visible = false;
                    imagebutton4.Visible = false;
                    break;
                case 2:
                    imagebutton1.Visible = false;
                    imagebutton2.Visible = true;
                    imagebutton3.Visible = false;
                    imagebutton4.Visible = false;
                    break;
                case 3:
                    imagebutton1.Visible = false;
                    imagebutton2.Visible = false;
                    imagebutton3.Visible = true;
                    imagebutton4.Visible = false;
                    break;
                case 4:
                    imagebutton1.Visible = false;
                    imagebutton2.Visible = false;
                    imagebutton3.Visible = false;
                    imagebutton4.Visible = true;
                    break;
            }

        }
        protected void Button1Clicked(object sender, EventArgs e)
        {
            imagebutton1.Visible = false;
            imagebutton2.Visible = true;
        }
        protected void Button2Clicked(object sender, EventArgs e)
        {
            imagebutton2.Visible = false;
            imagebutton4.Visible = true;
        }
        protected void Button3Clicked(object sender, EventArgs e)
        {
            imagebutton3.Visible = false;
            imagebutton1.Visible = true;
        }
        protected void Button4Clicked(object sender, EventArgs e)
        {
            imagebutton4.Visible = false;
            imagebutton3.Visible = true;
        }

    }
}